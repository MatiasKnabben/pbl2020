<template>
  <CadDoctor />
</template>

<script>
import CadDoctor from "../components/CadDoctor";

export default {
  name: "doutores",
  components: {
    CadDoctor
  }
};
</script>

<style></style>
