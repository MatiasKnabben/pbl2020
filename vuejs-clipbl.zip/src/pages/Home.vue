<template>
  <Dashboard />
</template>

<script>
import Dashboard from "../components/Dashboard";

export default {
  name: "home",
  components: {
    Dashboard
  }
};
</script>

<style></style>
