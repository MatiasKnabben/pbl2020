<template>
  <FormTodo />
</template>

<script>
import FormTodo from "../components/FormTodo";

export default {
  name: "FormCadPaciente",
  components: {
    FormTodo
  }
};
</script>

<style></style>
