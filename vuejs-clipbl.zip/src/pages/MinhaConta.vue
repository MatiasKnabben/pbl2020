<template>
  <MinhaConta />
</template>

<script>
import MinhaConta from "../components/MinhaConta";

export default {
  name: "minhaConta",
  components: {
    MinhaConta
  }
};
</script>

<style></style>
