<template>
  <Login />
</template>

<script>
import Login from "../components/Login";

export default {
  name: "login",
  components: {
    Login
  }
};
</script>

<style></style>
