<template>
  <TesteFormat />
</template>

<script>
import TesteFormat from "../components/TesteFormat";

export default {
  name: "testFormat",
  components: {
    TesteFormat
  }
};
</script>

<style></style>
