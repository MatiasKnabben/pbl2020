<template>
  <div class="container" style="max-width: 100%;">
    <NavBar></NavBar>
      <br />

<div class="container">

    <b-col md="auto">
      <b-calendar v-model="valueBusca" locale="en-US"></b-calendar>
    </b-col>
    
   <!-- <div v-on="datas in info" v-bind:key="datas">
           
            <p>{{ value }}</p>

            <p>{{ datas.Data == value }}</p>
            
    </div>
-->
        {{ valueBusca }}

    <button class="button" v-on:click.prevent="addList(valueBusca)" > SEARCH </button>

    <div v-for="busca in datas" v-bind:key="busca">
        <b-container class="bv-example-row mb-2">
          <b-row cols="6">
           <b-col md="2" class="list-group-item">
              <p class="comment_author">
                <strong>{{ busca.NomePaciente }}</strong>
              </p>
            </b-col>
            <b-col md="2" class="list-group-item">
              <p>
                <strong>{{ busca.Data | moment("DD/MM/YYYY") }}</strong>
              </p>
            </b-col>
            
            <b-col md="2" class="list-group-item">
              <p>
                <strong>{{ busca.HorarioEnt | moment("HH:mm") }}</strong>
              </p>
            </b-col>
            <b-col md="2" class="list-group-item">
              <p>
                <strong>{{ busca.HorarioSaida | moment("HH:mm") }}</strong>
              </p>
            </b-col>
          <b-col md="2" class="list-group-item">
              <p>
                <strong>{{ busca.doutor }}</strong>
              </p>
            </b-col>
          </b-row>
        </b-container>
      </div> 

   </div>
    <br />
    <Footer></Footer>
  </div>
</template>

<script>
import axios from 'axios';
import NavBar from "./NavBar";
import Footer from "./Footer";

export default {
  name: "Home",
  components: {
    NavBar,
    Footer,
  },
  data() {
    return {
    valueBusca: '',
    busca: [],
    datas: null,
    Dashboard: [],
    };
  },
  
   methods: {
      addList(valueBusca){
      axios
      .get("http://localhost:3000/agenda/list", { dataBusca: valueBusca })
      .then((response) => (this.datas = response.data));
      console.log(valueBusca);
      }
    
  },
};
</script>

<style scoped>
.lista {
  max-width: 100%;
}
.card{
  background-color: rgb(40, 48, 49);
  color: white;
}

.breadcome-list {
    padding-top: 30px;
    padding-bottom: 100px;
}

.breadcome-heading .form-control,
.breadcome-heading .form-control:focus {
    border: 1px solid #ececec;
    font-size: 13px;
    height: 34px;
    color: #303030;
    padding-left: 20px;
    padding-right: 40px;
    background: rgba(255, 255, 255, .1);
    box-shadow: none;
    border-radius: 30px;
    width: 200px;
}

.breadcome-heading a {
    position: absolute;
    top: 0;
    left: 178px;
    display: block;
    height: 34px;
    line-height: 34px;
    width: 34px;
    text-align: center;
    color: #999;
}

ul.breadcome-menu {
    text-align: right;
}

ul.breadcome-menu {
    padding-top: 8px;
}

ul {
    list-style: outside none none;
    margin: 0;
    padding: 0;
}


ul.breadcome-menu li {
    font-size: 14px;
    display: inline-block;
    color: #fff;
}

ul.breadcome-menu li a {
    color: #fff;
}

ul.breadcome-menu li {
    font-size: 14px;
    display: inline-block;
    color: #fff;
}
.dashboard_header 
{
    /* background: linear-gradient(0deg, #1143a6, 30%, #1197bf 70%); */
        background: linear-gradient(0deg, #0940af, 30%, #010e15 70%);
}
.pos_relative 
{
    
    position: absolute;
    top: 196px;
        width: 100%;

}
/* dashboard card start */
/* 
.update-card {
    color: #fff;
}

.bg-c-yellow {
    background: -webkit-gradient(linear, left top, right top, from(#fe9365), to(#feb798));
    background: linear-gradient(to right, #fe9365, #feb798);
}

.align-items-end {
    -ms-flex-align: end!important;
    align-items: flex-end!important;
}

.m-b-0 {
    margin-bottom: 0;
}

.update-card .card-footer {
    background-color: transparent;
    border-top: 1px solid #fff;
}

.m-b-0 {
    margin-bottom: 0;
} */




.panel-featured-primary {
    border-color: #08c;
}

.panel-featured-left {
    border-left: 3px solid #33353f;
        border-radius: 8px;
}

.panel-body {
    background: #fdfdfd;
    -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
    box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
    border-radius: 5px;
}


.widget-summary {
    display: table;
    width: 100%;
}

.widget-summary .widget-summary-col.widget-summary-col-icon {
    width: 1%;
}

.widget-summary .widget-summary-col {
    display: table-cell;
    vertical-align: top;
    width: 100%;
}


.widget-summary .summary-icon {
    margin-right: 8px;
        margin-left: 8px;
        margin-top: 8px;
    font-size: 42px;
    font-size: 4.2rem;
    width: 60px;
    height: 60px;
    line-height: 40px;
    text-align: center;
    color: #fff;
    -webkit-border-radius: 55px;
    border-radius: 55px;
}


.widget-summary .widget-summary-col {
    display: table-cell;
    vertical-align: top;
    width: 100%;
}


.widget-summary .summary {
    min-height: 65px;
    word-break: break-all;
}


.widget-summary .summary .title {
    margin: 0;
    font-size: 14px;
    line-height: 22px;
    color: #333;
    font-weight: 500;
}


.widget-summary .summary .info {
    font-size: 16px;
    line-height: 30px;
}

.widget-summary .summary .amount {
    margin-right: .2em;
    font-size: 16px;
    font-weight: 600;
    color: #333;
    vertical-align: middle;
}


.widget-summary .summary .info span {
    vertical-align: middle;
}
.summary-icon  i
{
    font-size: 35px;  
}

.widget-summary .summary-footer {
    padding: 8px 8px 8px;
    border-top: 1px dotted #ddd;
    text-align: right;
        font-size: 12px;
}

.bg-primary {
    background: #08c;
}
/* dashboard card end */
</style>
