<template>
  <div class="header">

    <b-navbar type="dark" variant="dark">
      <b-navbar-nav>
        
        <b-nav-item>
          
          UniAgn - Agenda Eletrônica
           
          </b-nav-item>
         
      </b-navbar-nav>
    </b-navbar>
<br />
    <br />
  </div>
</template>

<script>
</script>

<style scoped>
.header{
    width: 100%;
}
</style>
