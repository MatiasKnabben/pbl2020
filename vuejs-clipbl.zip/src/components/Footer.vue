<template>

    <footer class="footer1">
      <b-navbar type="dark" variant="dark">
      <b-navbar-nav> 
        <p>UniAGn © Copyright 2020</p> 
      </b-navbar-nav>
    </b-navbar>
      
    </footer>

</template>

<script></script>

<style scoped>
.footer1{
  max-width: 100%;
  width: 100%;
  position:fixed; 
  bottom:0;
  color: azure;
}
</style>